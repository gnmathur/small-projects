package dev.gmathur.datasink.policies

import scala.concurrent.duration.{Duration, DurationInt, FiniteDuration}

object BatchingPolicy {
  /** System-enforced maximum batch size */
  val MaxBatchSize = 10000
  /** System-enforced maximum flush interval for Time based batching policy */
  val MaxTimedFlushIntervalInSeconds: FiniteDuration = (5*60).seconds
}

/**
 * A batching policy will apply to records pending insertion into the database. The insertion queue is implementation
 * specific, but the batching policy will determine when to flush the queue.
 */
sealed trait AsyncBatchingPolicy

/** Flush all records at the next opportunity */
case object NoBatchingPolicy extends AsyncBatchingPolicy

/** Flush a batch when the number of pending records exceeds the batchSize. Records will be flushed at most every maxWait, regardless of batchSize. This
 * prevents the records from being stuck in the queue indefinitely.
 */
case class SizeBasedBatchingPolicy(batchSize: Long, maxWait: Duration) extends AsyncBatchingPolicy {
  require(batchSize <= BatchingPolicy.MaxBatchSize,
    "Batch size should less than system-enforced limit of ${BatchingPolicy.MaxBatchSize}")
  require(maxWait.toSeconds < BatchingPolicy.MaxTimedFlushIntervalInSeconds.toSeconds,
    "Max wait time should be less than system-enforced limit of ${BatchingPolicy.MaxTimedFlushIntervalInSeconds}")
}

/** Flush a batch every period */
case class TimeBasedBatchingPolicy(period: FiniteDuration) extends AsyncBatchingPolicy {
  require(period.toSeconds < BatchingPolicy.MaxTimedFlushIntervalInSeconds.toSeconds,
    "Period should be less than system-enforced limit of ${BatchingPolicy.MaxTimedFlushIntervalInSeconds}")
}

