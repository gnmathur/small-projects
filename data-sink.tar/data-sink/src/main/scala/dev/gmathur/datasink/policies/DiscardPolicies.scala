package dev.gmathur.datasink.policies

abstract class AsyncDiscardPolicy

/** Remove the oldest pending rows from the queue to make room for the new row tuples */
case class DiscardOldest(maxQueueSize: Int) extends AsyncDiscardPolicy

/** Remove the newest pending rows from the queue to make room for the new row tuples */
case class DiscardNewest(maxQueueSize: Int) extends AsyncDiscardPolicy

/** If the queue is full, block the caller */
case class BlockCaller(maxQueueSize: Int) extends AsyncDiscardPolicy

