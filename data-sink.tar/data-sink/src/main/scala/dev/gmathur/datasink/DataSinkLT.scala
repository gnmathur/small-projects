package dev.gmathur.datasink

import dev.gmathur.datasink.policies.{NoBatchingPolicy, SizeBasedBatchingPolicy, TimeBasedBatchingPolicy}

import java.util.concurrent.{BlockingQueue, Executors}

object DataSinkLT {
  def apply(config: DataSinkConfig) = new DataSinkLT(config)
}

class DataSinkLT(config: DataSinkConfig) extends DataSink(config) {
  /** Queue for batched writes. In synchronous mode, the batch will be written to queue and flushed immediately */
  private val queue: BlockingQueue[Any] = createQueue()

  /** Scheduler timed flush */
  private val scheduler = Executors.newScheduledThreadPool(1);

  private def createScheduler(): Unit = config.batchingPolicy.get match {
    // Create an {@code scheduleAtFixedRate} scheduler to flush the queue at {@code period} interval. Use the
    // {@code flush} method as the task to be executed
    case SizeBasedBatchingPolicy(_, period) => ???
    // Create an {@code scheduleAtFixedRate} scheduler to flush the queue at {@code period} interval. Use the
    // {@code flush} method as the task to be executed
    case TimeBasedBatchingPolicy(period) => ???
    case NoBatchingPolicy =>
  }

  /**
   * Create a queue based on the discard policy configuration. ArrayBlockingQueue and LinkedBlockingQueue are the
   * two options available that can be used to create a queue if the DataSink. Override the
   * {@code offer} method to implement the discard rule for discard policy.
   *
   * If the data sink is operating in synchronous mode, then the queue could be any Blocking queue. Just add a suitable
   * limit to the queue size.
   *
   * @tparam T Row type to be inserted
   * @return BlockingQueue[T]
   */
  private def createQueue[T](): BlockingQueue[T] = ???

  /**
   * SqltMap example usage:
   *
   * {{{
   *    val ds = DataSinkLT(new DataSinkConfig(WritePolicies.Always, new NoBatchingPolicy, false))
   *    ...
   *    val telemetryFanStatsTable = 'telemetry_fan_health
   *     val row: Seq[SqltMap] = Seq(SqltMap(
   *         'node_id -> nodeId,
   *         'node_group_id -> nodeGroupId,
   *         'organization_id -> organizationId,
   *         'fan_id -> fanId,
   *         'ts -> ts,
   *         'state -> state,
   *         'rpm -> rpm,
   *         'pwm -> pwm
   *     ))
   *     ds.insert(telemetryFanStatsTable.toString(), row)
   * }}}
   *
   * @param collection LT Table name
   * @param records SqltMap records to insert
   * @return
   */
  def insert(collection: String, records: Iterable[Any]): Unit = {
    // Add to queue

    // If async, and batching policy is size based, check if the queue is full and flush manually. Use flushAsync
    // If async, and batching policy is time based, then return immediately. The scheduler will flush the queue

    // If sync, flush the queue. Use flush method
  }

  /**
   * Flush all pending writes from the queue. Flush all records to the Datastore asynchronously, and clear the queue.
   *
   * @param ev ExecutionContext from the AsyncThreadingPolicy
   */
  private def flush(): Unit = ???

  /**
   * Wrapper routine to flush the queue. Wraps {@code flush} method to flush the queue to execute the flush in
   * a separate thread. This routine
   *
   * @param ev ExecutionContext from the AsyncThreadingPolicy
   */
  private def flushAsync(): Unit = {
    /** complete the ExecutionContext from the AsyncThreadingPolicy based on the table name. For some policies, the
     * ExecutionContext is table specific. For example, in the ThreadPerTable policy, the ExecutionContext is specific
     * to the table name. In such cases, the ExecutionContext should be retrieved as follows:
     * {{{
     *  implicit val ec = getAsyncThreadingPolicy.get.getExecutionContext(Some("foo"))
     * }}}
     *
     * For non-table specific ExecutionContext, fetch the execution context from the policy by passing None as the
     * table name. For example, in the SingleThreadAllTables policy, the ExecutionContext is not table specific. In such
     * cases, the ExecutionContext should be retrieved as follows:
     * {{{
     *   implicit val ec = getAsyncThreadingPolicy.get.getExecutionContext(None)
     * }}}
     */
    implicit val ec = ???
    // Write the datastore specific insert as a future here.
  }

  override def init(): Boolean = {
    super.init()
    ???
  }

  override def shutdown(): Unit = {
    super.shutdown()

    // Flush pending writes. Can use sync flush here

    // Shutdown the scheduler
    ???
  }
}

