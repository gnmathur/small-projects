package dev.gmathur.datasink.policies

import java.util.concurrent.Executors
import scala.concurrent.ExecutionContext

/**
 * This policy dictates how the underlying threads should be created for DataSink operating in async mode
 */
abstract class AsyncThreadingPolicy {
  def getExecutionContext(table: Option[String]): ExecutionContext
}

/** Use a single thread for all pending writes across all tables */
case object SingleThreadAllTables extends AsyncThreadingPolicy {
  private lazy val ec = ExecutionContext.fromExecutorService(Executors.newSingleThreadExecutor())

  override def getExecutionContext(table: Option[String]): ExecutionContext = ec
}

/** Use multiple threads for all pending writes, across all table */
case class MultipleThreadsAllTables(size: Int) extends AsyncThreadingPolicy {
  require(size > 0, "Thread count for async dispatch should be a positive interger")

  private lazy val ec = ExecutionContext.fromExecutorService(Executors.newFixedThreadPool(size))

  override def getExecutionContext(table: Option[String]): ExecutionContext = ec
}

/** Use a thread per table. All writes to a specific table will be handled by a bespoke thread */
case object ThreadPerTable extends AsyncThreadingPolicy {
  private lazy val tableExecutionContexts = scala.collection.mutable.Map[String, ExecutionContext]()

  private def createExecutionContext(): ExecutionContext = {
    ExecutionContext.fromExecutorService(Executors.newSingleThreadExecutor())
  }
  override def getExecutionContext(table: Option[String]): ExecutionContext = {
    table match {
      case Some(tbl) => tableExecutionContexts.getOrElseUpdate(tbl, createExecutionContext())
      case None => ExecutionContext.global
    }
  }
}
