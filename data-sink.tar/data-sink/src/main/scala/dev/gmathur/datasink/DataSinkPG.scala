package dev.gmathur.datasink

object DataSinkPG {
  /**
   * Build a PG DataSink
   */
  def apply(config: DataSinkConfig) = new DataSinkPG(config)
}

class DataSinkPG(config: DataSinkConfig) extends DataSink(config) {
  /** Insert a single or vector of Col->Row tuple
   *
   * Example usage:
   *
   * {{{
   *   val ds = DataSinkPG(Always, NoBatchingPolicy, false)
   *   val row = Seq[(Sql, JdbcArg)](
   *     'network_id -> nodeGroupId,
   *     'created_at -> PgNow,
   *     'node_id -> node.id,
   *     'event_type -> EventType,
   *     'event_time -> dhcpServer.lastSeenAt,
   *     'notify_at -> PgNow,
   *     'event_data -> dhcpServer.alertEventJson,
   *     'description -> dhcpServer.key(nodeGroupId)
   *   )
   *   ds.insert("network_events", row)
   * }}}
   * */
  def insert(collection: String, records: Iterable[Iterable[(String, Any)]]): Unit = ???

  /** Initialize the DataSink layer */
  override def init(): Boolean = {
    super.init()
    ???
  }

  /** Shutdown the DataSink layer. Flush all pending writes */
  override def shutdown(): Unit = {
    super.shutdown()
    ???
  }
}
