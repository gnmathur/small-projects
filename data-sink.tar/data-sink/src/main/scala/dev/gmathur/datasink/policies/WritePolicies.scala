package dev.gmathur.datasink.policies

/**
 * Write policies decide whether an incoming record should be written to the sink or not.
 * They can also take action when a record is discarded.
 */
trait WritePolicy {
  def shouldWrite[R](record: R): Boolean
  def onDiscard[R](record: R): Unit
}

/** Always accept an incoming record for write */
object Always extends WritePolicy {
  override def shouldWrite[R](record: R): Boolean = true
  override def onDiscard[R](record: R): Unit = {}
}

/** Always discard an incoming record */
object Never extends WritePolicy {
  override def shouldWrite[R](record: R): Boolean = false
  override def onDiscard[R](record: R): Unit = {}
}

/** Deduplicate incoming records based on the key
 *
 * Deduplicate based on SqlRow and SqltMap information in case of LT for instance. This version is not as typesafe as I would prefer because
 * it does not really check the type of dedupFn type parameter.
 */
class Deduplication[T](dedupFn: List[T] => List[T]) extends WritePolicy {
  override def shouldWrite[R](record: R): Boolean = ???
  override def onDiscard[R](record: R): Unit = ???
}

