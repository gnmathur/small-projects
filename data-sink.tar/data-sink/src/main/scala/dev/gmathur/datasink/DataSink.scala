package dev.gmathur.datasink

import dev.gmathur.datasink.policies.{Always, AsyncBatchingPolicy, AsyncDiscardPolicy, AsyncThreadingPolicy, WritePolicy}

case class DataSinkConfig(
                           writePolicy: WritePolicy = Always,
                           batchingPolicy: Option[AsyncBatchingPolicy] = None,
                           discardPolicy: Option[AsyncDiscardPolicy] = None,
                           asyncThreadingPolicy: Option[AsyncThreadingPolicy] = None,
                           isAsync: Boolean = false) {
  if (isAsync) {
    require(batchingPolicy.isDefined, "A batching policy must be defined when DataSink is operating in async mode")
    require(discardPolicy.isDefined, "A discard policy must be defined when DataSink is operating in async mode")
    require(asyncThreadingPolicy.isDefined, "An async threading policy must be defined when DataSink is operating in async mode")
  }
  if (!isAsync) {
    require(batchingPolicy.isEmpty, "A batching policy must not be defined when DataSink is operating in sync mode")
    require(discardPolicy.isEmpty, "A discard policy must not be defined when DataSink is operating in sync mode")
    require(asyncThreadingPolicy.isEmpty, "An async threading policy must not be defined when DataSink is operating in sync mode")
  }
}

/**
 * Creates an instance of a data sink. This holds the higher-level configuration for the data sink. Data-store-specific
 * instances will be created from this.
 *
 * @param writePolicy Write filter for all incoming inserts
 * @param batchingPolicy Batching policy to use in case of asynchronous mode. Ignored in synchronous mode
 * @param async Does the Data Sink operate in synchronous or asynchronous mode
 */
abstract class DataSink(config: DataSinkConfig) {
  /** Initialize the DataSink layer */
  def init(): Boolean = ???

  /** Shutdown the DataSink layer. Flush all pending writes */
  def shutdown(): Unit = ???

  /** Config and policy getters */
  def getWritePolicy: WritePolicy = config.writePolicy
  def getBatchingPolicy: Option[AsyncBatchingPolicy] = config.batchingPolicy
  def getDiscardPolicy: Option[AsyncDiscardPolicy] = config.discardPolicy
  def getAsyncThreadingPolicy = config.asyncThreadingPolicy
  def isAsync: Boolean = config.isAsync
}
